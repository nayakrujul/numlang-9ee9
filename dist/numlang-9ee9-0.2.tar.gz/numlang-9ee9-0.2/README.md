# numlang-9ee9
A very concise language for processing numbers.
